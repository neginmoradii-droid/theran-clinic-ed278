var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/generar-pago.js
var generar_pago_exports = {};
__export(generar_pago_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(generar_pago_exports);
var import_node_crypto = __toESM(require("crypto"), 1);
var SECRET_KEY = "+FBv/qS9vwsDZPgZu/CWFUOaS9XGrRbW";
var MERCHANT_CODE = "370476756";
var TERMINAL = "001";
var AMOUNT = "1500";
var CURRENCY = "978";
var REDSYS_URL = "https://sis.redsys.es/sis/realizarPago";
function base64UrlDecode(str) {
  return Buffer.from(str.replace(/-/g, "+").replace(/_/g, "/"), "base64");
}
function base64UrlEncode(buf) {
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_");
}
function encrypt3DES(message, key) {
  const msgBuf = Buffer.from(message, "utf8");
  const l = Math.ceil(msgBuf.length / 8) * 8;
  const padded = Buffer.alloc(l, 0);
  msgBuf.copy(padded);
  const iv = Buffer.alloc(8, 0);
  const cipher = import_node_crypto.default.createCipheriv("des-ede3-cbc", key, iv);
  cipher.setAutoPadding(false);
  const enc = Buffer.concat([cipher.update(padded), cipher.final()]);
  return enc.slice(0, l);
}
function redsysSignature(paramsB64, order) {
  const key = base64UrlDecode(SECRET_KEY);
  const keyOrder = encrypt3DES(order, key);
  const hmac = import_node_crypto.default.createHmac("sha256", keyOrder);
  hmac.update(paramsB64);
  return base64UrlEncode(hmac.digest());
}
var CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json"
};
var handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: CORS, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  let body;
  try {
    body = JSON.parse(event.body || "{}");
  } catch (e) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Invalid JSON" }) };
  }
  const { nombre, email, telefono } = body;
  if (!nombre || !email || !telefono) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ error: "Faltan datos." }) };
  }
  const ts = Date.now().toString();
  const order = ts.slice(-12).padStart(12, "0");
  const urlBase = "https://theranclinic.com";
  const merchantData = `Nombre: ${nombre} | Email: ${email} | Tel: ${telefono}`;
  const merchantParams = {
    DS_MERCHANT_AMOUNT: AMOUNT,
    DS_MERCHANT_ORDER: order,
    DS_MERCHANT_MERCHANTCODE: MERCHANT_CODE,
    DS_MERCHANT_CURRENCY: CURRENCY,
    DS_MERCHANT_TRANSACTIONTYPE: "0",
    DS_MERCHANT_TERMINAL: TERMINAL,
    DS_MERCHANT_URLOK: `${urlBase}/reserva-confirmada/`,
    DS_MERCHANT_URLKO: `${urlBase}/reserva-error/`,
    DS_MERCHANT_MERCHANTNAME: "THERAN Clinic",
    DS_MERCHANT_PRODUCTDESCRIPTION: "Dep\xF3sito reserva cita - 15\u20AC",
    DS_MERCHANT_TITULAR: nombre,
    DS_MERCHANT_MERCHANTDATA: merchantData
  };
  const paramsJson = JSON.stringify(merchantParams);
  const paramsB64 = Buffer.from(paramsJson).toString("base64");
  const signature = redsysSignature(paramsB64, order);
  return {
    statusCode: 200,
    headers: CORS,
    body: JSON.stringify({
      url: REDSYS_URL,
      params_b64: paramsB64,
      signature
    })
  };
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
